from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///inventory.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Product(db.Model):
    product_id = db.Column(db.String, primary_key=True)
    name = db.Column(db.String, nullable=False)

class Location(db.Model):
    location_id = db.Column(db.String, primary_key=True)
    name = db.Column(db.String, nullable=False)

class ProductMovement(db.Model):
    movement_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    from_location = db.Column(db.String, db.ForeignKey('location.location_id'))
    to_location = db.Column(db.String, db.ForeignKey('location.location_id'))
    product_id = db.Column(db.String, db.ForeignKey('product.product_id'))
    qty = db.Column(db.Integer, nullable=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/products', methods=['GET', 'POST'])
def products():
    if request.method == 'POST':
        pid = request.form['product_id']
        name = request.form['name']
        db.session.add(Product(product_id=pid, name=name))
        db.session.commit()
        return redirect('/products')
    products = Product.query.all()
    return render_template('products.html', products=products)

@app.route('/locations', methods=['GET', 'POST'])
def locations():
    if request.method == 'POST':
        lid = request.form['location_id']
        name = request.form['name']
        db.session.add(Location(location_id=lid, name=name))
        db.session.commit()
        return redirect('/locations')
    locations = Location.query.all()
    return render_template('locations.html', locations=locations)

@app.route('/movements', methods=['GET', 'POST'])
def movements():
    products = Product.query.all()
    locations = Location.query.all()
    if request.method == 'POST':
        movement = ProductMovement(
            from_location=request.form.get('from_location') or None,
            to_location=request.form.get('to_location') or None,
            product_id=request.form['product_id'],
            qty=int(request.form['qty'])
        )
        db.session.add(movement)
        db.session.commit()
        return redirect('/movements')
    movements = ProductMovement.query.all()
    return render_template('movements.html', movements=movements, products=products, locations=locations)

@app.route('/report')
def report():
    locations = Location.query.all()
    products = Product.query.all()
    report_data = []
    for p in products:
        for l in locations:
            in_qty = db.session.query(db.func.sum(ProductMovement.qty)).filter_by(to_location=l.location_id, product_id=p.product_id).scalar() or 0
            out_qty = db.session.query(db.func.sum(ProductMovement.qty)).filter_by(from_location=l.location_id, product_id=p.product_id).scalar() or 0
            balance = in_qty - out_qty
            if balance != 0:
                report_data.append({'product': p.name, 'location': l.name, 'qty': balance})
    return render_template('report.html', report=report_data)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
