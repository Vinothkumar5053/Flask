# Inventory Management Web Application

Simple Flask-based inventory management system.

## How to Run
1. Install dependencies
   ```bash
   pip install -r requirements.txt
   ```
2. Create the database
   ```bash
   python create_db.py
   ```
3. Run the application
   ```bash
   python app.py
   ```
4. Open http://127.0.0.1:5000 in your browser.
